# Writing an agent for this harness

Generated from the vendor's own reference and the pinned binary. Do not edit: the next render overwrites it, and a correction belongs in the source this file is derived from.

**Where it goes**: `~/.config/opencode/agents/<name>.md`

**Decided by**: https://opencode.ai/docs/agents

**How it runs**: `@<name>`, which is the filename without `.md` unless frontmatter gives a `name`.

## Frontmatter

| field | required | what it does |
|---|---|---|
| `description` | **yes** | What the agent is for. |
| `name` | no | Replaces the name the filename gives, entirely -- the agent is then reachable only under this one. |
| `mode` | no | `primary`, `subagent` or `all`. |
| `model` | no | Model override. |
| `temperature` | no | Sampling temperature. |
| `top_p` | no | Nucleus sampling. |
| `tools` | no | Enable or disable tools. |
| `permission` | no | `allow`, `deny` or `ask`; keys are matched as wildcard patterns against the tool name, so the same syntax covers built-ins, custom tools and MCP tools. |
| `disable` | no | Boolean. |
| `color` | no | Display colour. |

## What bites

- **A `name` in frontmatter replaces the one the filename gives, and it replaces it entirely.** Measured 2026-08-31 by running the 1.18.25 binary against a temporary home: an agent file named for one thing and carrying `name:` for another is reachable only under the frontmatter name -- `debug agent` given the filename does not find it, and `agent list` prints the frontmatter name alone. This reference said the opposite until then, that there is no `name` field and the filename is the identity, and the sentence had a citation rather than a run behind it.
- **So name it once.** The filename and a frontmatter `name` are two places to say the same thing, and when they disagree the file is reachable under a name its path does not show -- which is a component this provider owns and a person cannot find. Either leave `name` out or keep it equal to the filename.

## The same file on the other harnesses

Generated from the same rows as the section above, for every harness in this estate that routes this kind. `—` means the product's own reference does not name the field, and **dropped** means it names it as one it accepts and does not act on.

| field | `claude` | `grok` | `opencode` | `antigravity` |
|---|---|---|---|---|
| `name` | **required** | — | yes | **required** |
| `description` | **required** | — | **required** | **required** |
| `tools` | yes | — | yes | yes |
| `disallowedTools` | yes | — | — | — |
| `model` | yes | — | yes | yes |
| `permissionMode` | yes | yes | — | — |
| `maxTurns` | yes | — | — | — |
| `skills` | yes | — | — | yes |
| `mcpServers` | yes | yes | — | yes |
| `hooks` | yes | yes | — | — |
| `memory` | yes | — | — | — |
| `background` | yes | — | — | — |
| `effort` | yes | — | — | — |
| `isolation` | yes | — | — | — |
| `color` | yes | — | yes | — |
| `initialPrompt` | yes | — | — | — |
| `mcpInheritance` | — | yes | — | — |
| `mode` | — | — | yes | — |
| `temperature` | — | — | yes | — |
| `top_p` | — | — | yes | — |
| `permission` | — | — | yes | — |
| `disable` | — | — | yes | — |
| `mainAgent` | — | — | — | yes |
| `subagent` | — | — | — | yes |
| `commandExecutionPolicy` | — | — | — | yes |

**The part that does not, and says nothing when it does not**: a field absent from a column is not rejected there -- it is read past. Nothing warns, no run fails, and the component behaves differently with the same bytes. Where the field was carrying a restriction, the restriction is simply gone. Check the column before relying on one.

## Before you ship one

- **The surface is declared, so the component is a promise.** Every kind   this provider declares is a promise of a rollback. A component written   to a path the declaration does not carry is installed by nobody and   removed by nobody.
- **Name it once.** Where the product derives identity from the directory   or the filename, the frontmatter `name` is either redundant or a second   place to be wrong. Keep them equal.
- **Read it back.** After an install, look at the file where the product   reads it, not at the step that put it there.
