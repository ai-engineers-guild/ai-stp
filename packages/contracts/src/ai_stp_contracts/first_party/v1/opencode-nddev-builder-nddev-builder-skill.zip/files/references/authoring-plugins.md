# Writing a plugin for this harness

Generated from the vendor's own reference and the pinned binary. Do not edit: the next render overwrites it, and a correction belongs in the source this file is derived from.

**Where it goes**: `~/.config/opencode/plugins/<name>.ts` or `<name>.js`

**Decided by**: https://opencode.ai/docs/plugins

**How it runs**: Every JavaScript or TypeScript file in the plugins directory is loaded at startup.

## Contract

| export | required | what it does |
|---|---|---|
| `named export` | **yes** | An async function taking a context object with `project`, `client`, `$`, `directory` and `worktree`, returning an object of hooks. |
| `tool.execute.before` | no | Runs before a tool call; the usual place a plugin gates one. |
| `tool.execute.after` | no | Runs after a tool call. |
| `permission.asked` | no | Fires when a permission is requested. |
| `permission.replied` | no | Fires when one is answered. |
| `session.created` | no | One of the session lifecycle events, alongside `session.compacted`, `session.deleted`, `session.error`, `session.idle` and others. |
| `file.edited` | no | Fires on an edit; `file.watcher.updated` on a watched change. |
| `command.executed` | no | Fires after a command runs. |
| `shell.env` | no | Contributes environment to shell invocations. |

## What bites

- **This is code, loaded automatically at startup.** Any file in the directory is loaded -- there is no manifest to opt one in and no field to disable one, so a file left behind by a half-finished install still runs.
- npm dependencies are installed with Bun at startup and cached outside the configuration home. A restore that returns this directory does not return that cache, and the first launch after one reaches the network.
- The load order is global config, then project config, then the global plugin directory, then the project one.

## The same file on the other harnesses

Generated from the same rows as the section above, for every harness in this estate that routes this kind. `—` means the product's own reference does not name the field, and **dropped** means it names it as one it accepts and does not act on.

| field | `pi` | `opencode` |
|---|---|---|
| `default export` | **required** | — |
| `package.json `pi.extensions`` | yes | — |
| `pi.registerTool()` | yes | — |
| `pi.registerCommand()` | yes | — |
| `pi.on()` | yes | — |
| `pi.registerShortcut()` | yes | — |
| `pi.registerFlag()` | yes | — |
| `pi.registerProvider()` | yes | — |
| `named export` | — | **required** |
| `tool.execute.before` | — | yes |
| `tool.execute.after` | — | yes |
| `permission.asked` | — | yes |
| `permission.replied` | — | yes |
| `session.created` | — | yes |
| `file.edited` | — | yes |
| `command.executed` | — | yes |
| `shell.env` | — | yes |

**The part that does not, and says nothing when it does not**: a field absent from a column is not rejected there -- it is read past. Nothing warns, no run fails, and the component behaves differently with the same bytes. Where the field was carrying a restriction, the restriction is simply gone. Check the column before relying on one.

## Before you ship one

- **The surface is declared, so the component is a promise.** Every kind   this provider declares is a promise of a rollback. A component written   to a path the declaration does not carry is installed by nobody and   removed by nobody.
- **Name it once.** Where the product derives identity from the directory   or the filename, the frontmatter `name` is either redundant or a second   place to be wrong. Keep them equal.
- **Read it back.** After an install, look at the file where the product   reads it, not at the step that put it there.
