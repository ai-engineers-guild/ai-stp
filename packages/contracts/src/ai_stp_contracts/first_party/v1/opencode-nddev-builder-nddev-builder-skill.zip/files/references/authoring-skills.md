# Writing a skill for this harness

Generated from the vendor's own reference and the pinned binary. Do not edit: the next render overwrites it, and a correction belongs in the source this file is derived from.

**Where it goes**: `~/.config/opencode/skills/<name>/SKILL.md`

**Decided by**: https://opencode.ai/docs/skills

**How it runs**: An agent loads it with `skill({ name: "<name>" })`.

## Frontmatter

| field | required | what it does |
|---|---|---|
| `name` | **yes** | 1-64 characters matching `^[a-z0-9]+(-[a-z0-9]+)*$`, and it **must equal the directory name**. |
| `description` | **yes** | 1-1024 characters, specific enough to select on. |
| `license` | no | Licence for the skill. |
| `compatibility` | no | Framework compatibility. |
| `metadata` | no | String-to-string map. |

## What bites

- **Unknown fields are disregarded, silently.** This is the harness that makes the portability table below worth reading: a skill carrying `allowed-tools` is accepted here and the field does nothing, so a control that holds on three harnesses is absent on the fourth with no error anywhere.
- This product accepts the singular and the plural spelling of the directory. This provider owns the plural only, and `surfaces` records the singular among the paths deliberately not owned, with the reason.

## The same file on the other harnesses

Generated from the same rows as the section above, for every harness in this estate that routes this kind. `—` means the product's own reference does not name the field, and **dropped** means it names it as one it accepts and does not act on.

| field | `claude` | `grok` | `pi` | `opencode` | `cursor` | `antigravity` |
|---|---|---|---|---|---|---|
| `name` | yes | yes | **required** | **required** | **required** | yes |
| `description` | yes | yes | **required** | **required** | **required** | **required** |
| `argument-hint` | yes | yes | — | — | — | — |
| `arguments` | yes | — | — | — | — | — |
| `allowed-tools` | yes | **dropped** | yes | — | — | — |
| `disallowed-tools` | yes | — | — | — | — | — |
| `disable-model-invocation` | yes | yes | yes | — | yes | — |
| `user-invocable` | yes | yes | — | — | — | — |
| `model` | yes | **dropped** | — | — | — | — |
| `effort` | yes | **dropped** | — | — | — | — |
| `context` | yes | — | — | — | — | — |
| `agent` | yes | — | — | — | — | — |
| `background` | yes | — | — | — | — | — |
| `hooks` | yes | — | — | — | — | — |
| `paths` | yes | yes | — | — | yes | — |
| `shell` | yes | — | — | — | — | — |
| `metadata` | yes | yes | yes | yes | yes | — |
| `license` | yes | **dropped** | yes | yes | — | — |
| `compatibility` | yes | **dropped** | yes | yes | — | — |
| `when_to_use` | yes | — | — | — | — | — |
| `when-to-use` | — | yes | — | — | — | — |
| `icon` | — | — | — | — | yes | — |
| `color` | — | — | — | — | yes | — |

**The part that travels**: `name`, `description`. Everything else is a bet on one product.

**The part that does not, and says nothing when it does not**: a field absent from a column is not rejected there -- it is read past. Nothing warns, no run fails, and the component behaves differently with the same bytes. Where the field was carrying a restriction, the restriction is simply gone. Check the column before relying on one.

## Before you ship one

- **The surface is declared, so the component is a promise.** Every kind   this provider declares is a promise of a rollback. A component written   to a path the declaration does not carry is installed by nobody and   removed by nobody.
- **Name it once.** Where the product derives identity from the directory   or the filename, the frontmatter `name` is either redundant or a second   place to be wrong. Keep them equal.
- **Read it back.** After an install, look at the file where the product   reads it, not at the step that put it there.
