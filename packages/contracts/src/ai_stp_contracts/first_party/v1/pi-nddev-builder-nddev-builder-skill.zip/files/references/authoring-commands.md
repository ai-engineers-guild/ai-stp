# Writing a command for this harness

Generated from the vendor's own reference and the pinned binary. Do not edit: the next render overwrites it, and a correction belongs in the source this file is derived from.

**Where it goes**: `~/.pi/agent/prompts/<name>.md`

**Decided by**: https://pi.dev/docs/latest/prompt-templates

**How it runs**: `/<filename without .md>`

## Frontmatter

| field | required | what it does |
|---|---|---|
| `description` | no | Shown in autocomplete. Defaults to the first non-empty line. |
| `argument-hint` | no | `<angle brackets>` required, `[square]` optional. |

## What bites

- Substitution is the richest of any harness here: `$1`, `$2`, `$@` or `$ARGUMENTS`, `${1:-default}` for a fallback, `${@:N}` from position N, and `${@:N:L}` for L arguments from N.
- Discovery is **not recursive**. A template in a subdirectory needs explicit configuration to be found.

## The same file on the other harnesses

Generated from the same rows as the section above, for every harness in this estate that routes this kind. `—` means the product's own reference does not name the field, and **dropped** means it names it as one it accepts and does not act on.

| field | `claude` | `codex` | `pi` | `opencode` | `cursor` | `antigravity` |
|---|---|---|---|---|---|---|
| `description` | yes | yes | yes | yes | yes | yes |
| `argument-hint` | yes | yes | yes | — | — | — |
| `name` | **dropped** | — | — | — | yes | — |
| `paths` | **dropped** | — | — | — | — | — |
| `agent` | — | — | — | yes | — | — |
| `model` | — | — | — | yes | — | — |
| `subtask` | — | — | — | yes | — | — |
| `title` | — | — | — | — | — | yes |

**The part that travels**: `description`. Everything else is a bet on one product.

**The part that does not, and says nothing when it does not**: a field absent from a column is not rejected there -- it is read past. Nothing warns, no run fails, and the component behaves differently with the same bytes. Where the field was carrying a restriction, the restriction is simply gone. Check the column before relying on one.

## Before you ship one

- **The surface is declared, so the component is a promise.** Every kind   this provider declares is a promise of a rollback. A component written   to a path the declaration does not carry is installed by nobody and   removed by nobody.
- **Name it once.** Where the product derives identity from the directory   or the filename, the frontmatter `name` is either redundant or a second   place to be wrong. Keep them equal.
- **Read it back.** After an install, look at the file where the product   reads it, not at the step that put it there.
