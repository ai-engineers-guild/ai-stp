# Writing a skill for this harness

Generated from the vendor's own reference and the pinned binary. Do not edit: the next render overwrites it, and a correction belongs in the source this file is derived from.

**Where it goes**: `~/.pi/agent/skills/<name>/SKILL.md`

**Decided by**: https://pi.dev/docs/latest/skills

**How it runs**: `/skill:<name>` or `/skill:<name> arguments`, appended as user input.

## Frontmatter

| field | required | what it does |
|---|---|---|
| `name` | **yes** | Max 64 characters, lowercase `a-z`, `0-9` and hyphens. |
| `description` | **yes** | Max 1024 characters: what it does and when to use it. |
| `license` | no | Licence name or file reference. |
| `compatibility` | no | Max 500 characters of environment requirements. |
| `metadata` | no | Arbitrary key-value mapping. |
| `allowed-tools` | no | Space-delimited pre-approved tool list. |
| `disable-model-invocation` | no | Hide the skill from the system prompt. |

## What bites

- The layout the vendor documents is `SKILL.md` at the root with optional `scripts/`, `references/` and `assets/` beside it -- the same shape this toolkit itself uses.
- This product also reads the shared convention root. That is recorded in `surfaces` among the paths deliberately not owned, measured in the pinned bundle rather than taken from a page.

## The same file on the other harnesses

Generated from the same rows as the section above, for every harness in this estate that routes this kind. `—` means the product's own reference does not name the field, and **dropped** means it names it as one it accepts and does not act on.

| field | `claude` | `grok` | `pi` | `opencode` | `cursor` | `antigravity` |
|---|---|---|---|---|---|---|
| `name` | yes | yes | **required** | **required** | **required** | yes |
| `description` | yes | yes | **required** | **required** | **required** | **required** |
| `argument-hint` | yes | yes | — | — | — | — |
| `arguments` | yes | — | — | — | — | — |
| `allowed-tools` | yes | **dropped** | yes | — | — | — |
| `disallowed-tools` | yes | — | — | — | — | — |
| `disable-model-invocation` | yes | yes | yes | — | yes | — |
| `user-invocable` | yes | yes | — | — | — | — |
| `model` | yes | **dropped** | — | — | — | — |
| `effort` | yes | **dropped** | — | — | — | — |
| `context` | yes | — | — | — | — | — |
| `agent` | yes | — | — | — | — | — |
| `background` | yes | — | — | — | — | — |
| `hooks` | yes | — | — | — | — | — |
| `paths` | yes | yes | — | — | yes | — |
| `shell` | yes | — | — | — | — | — |
| `metadata` | yes | yes | yes | yes | yes | — |
| `license` | yes | **dropped** | yes | yes | — | — |
| `compatibility` | yes | **dropped** | yes | yes | — | — |
| `when_to_use` | yes | — | — | — | — | — |
| `when-to-use` | — | yes | — | — | — | — |
| `icon` | — | — | — | — | yes | — |
| `color` | — | — | — | — | yes | — |

**The part that travels**: `name`, `description`. Everything else is a bet on one product.

**The part that does not, and says nothing when it does not**: a field absent from a column is not rejected there -- it is read past. Nothing warns, no run fails, and the component behaves differently with the same bytes. Where the field was carrying a restriction, the restriction is simply gone. Check the column before relying on one.

## Before you ship one

- **The surface is declared, so the component is a promise.** Every kind   this provider declares is a promise of a rollback. A component written   to a path the declaration does not carry is installed by nobody and   removed by nobody.
- **Name it once.** Where the product derives identity from the directory   or the filename, the frontmatter `name` is either redundant or a second   place to be wrong. Keep them equal.
- **Read it back.** After an install, look at the file where the product   reads it, not at the step that put it there.
