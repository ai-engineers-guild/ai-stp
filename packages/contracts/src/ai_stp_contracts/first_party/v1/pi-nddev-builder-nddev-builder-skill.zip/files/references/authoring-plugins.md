# Writing a plugin for this harness

Generated from the vendor's own reference and the pinned binary. Do not edit: the next render overwrites it, and a correction belongs in the source this file is derived from.

**Where it goes**: `~/.pi/agent/extensions/<name>.ts` or `<name>/index.ts`

**Decided by**: https://pi.dev/docs/latest/extensions

**How it runs**: Discovered as `<name>.ts` or `<name>/index.ts` and loaded at startup.

## Contract

| export | required | what it does |
|---|---|---|
| `default export` | **yes** | A factory function taking `ExtensionAPI`. It may be async, and it runs before `session_start` completes. |
| `package.json `pi.extensions`` | no | Entry points, for a multi-file extension with dependencies. |
| `pi.registerTool()` | no | A tool the model may call. |
| `pi.registerCommand()` | no | A `/command`. |
| `pi.on()` | no | An event subscription. |
| `pi.registerShortcut()` | no | A keyboard binding. |
| `pi.registerFlag()` | no | A CLI flag. |
| `pi.registerProvider()` | no | A model provider, registered dynamically. |

## What bites

- **This is code, and the vendor says plainly that it runs with full system permissions.** A setup that installs one is installing a program that runs on the next launch, not a document the product reads. Treat adding one as a decision a person makes, and say in the setup's description that it carries executable content.
- A project-local extension loads only after the project is explicitly trusted. A global one -- which is where a setup aimed at the configuration home puts it -- has no such gate.
- Extensions do **not** contribute skills, prompts or themes. Those load from their own resource paths, so a plugin is not a way to ship one.

## The same file on the other harnesses

Generated from the same rows as the section above, for every harness in this estate that routes this kind. `—` means the product's own reference does not name the field, and **dropped** means it names it as one it accepts and does not act on.

| field | `pi` | `opencode` |
|---|---|---|
| `default export` | **required** | — |
| `package.json `pi.extensions`` | yes | — |
| `pi.registerTool()` | yes | — |
| `pi.registerCommand()` | yes | — |
| `pi.on()` | yes | — |
| `pi.registerShortcut()` | yes | — |
| `pi.registerFlag()` | yes | — |
| `pi.registerProvider()` | yes | — |
| `named export` | — | **required** |
| `tool.execute.before` | — | yes |
| `tool.execute.after` | — | yes |
| `permission.asked` | — | yes |
| `permission.replied` | — | yes |
| `session.created` | — | yes |
| `file.edited` | — | yes |
| `command.executed` | — | yes |
| `shell.env` | — | yes |

**The part that does not, and says nothing when it does not**: a field absent from a column is not rejected there -- it is read past. Nothing warns, no run fails, and the component behaves differently with the same bytes. Where the field was carrying a restriction, the restriction is simply gone. Check the column before relying on one.

## Before you ship one

- **The surface is declared, so the component is a promise.** Every kind   this provider declares is a promise of a rollback. A component written   to a path the declaration does not carry is installed by nobody and   removed by nobody.
- **Name it once.** Where the product derives identity from the directory   or the filename, the frontmatter `name` is either redundant or a second   place to be wrong. Keep them equal.
- **Read it back.** After an install, look at the file where the product   reads it, not at the step that put it there.
