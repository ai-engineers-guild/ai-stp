# Writing a plugin for this harness

Generated from the vendor's own reference and the pinned binary. Do not edit: the next render overwrites it, and a correction belongs in the source this file is derived from.

**Where it goes**: `~/.cursor/plugins/local/<name>/.cursor-plugin/plugin.json`

**Decided by**: https://cursor.com/docs/reference/plugins

**How it runs**: Loaded when the plugin is enabled. Components are discovered by convention -- `skills/`, `rules/`, `agents/`, `commands/`, `hooks/hooks.json`, `mcp.json` -- unless the manifest names a path instead.

## Manifest

| key | required | what it does |
|---|---|---|
| `name` | **yes** | Plugin identifier. Lowercase kebab-case -- alphanumerics, hyphens and periods -- beginning and ending with an alphanumeric. |
| `description` | no | Brief plugin description. |
| `version` | no | Semantic version. |
| `author` | no | Object with `name` (required) and `email`. |
| `homepage` | no | URL. |
| `repository` | no | URL. |
| `license` | no | SPDX-style identifier. |
| `keywords` | no | Array of tags for discovery. |
| `logo` | no | Relative path to a logo committed in the repository, or an absolute URL. |
| `rules` | no | Path or paths to rule files or directories. |
| `agents` | no | Path or paths to agent files or directories. **This is how an agent reaches this product**, the directory under the configuration home being workspace-scoped only. |
| `skills` | no | Path or paths to skill directories. |
| `commands` | no | Path or paths to command files or directories. |
| `hooks` | no | Path to a hooks config file, or inline hook config. |
| `mcpServers` | no | Path, object or array. Overrides the default `mcp.json` discovery. |
| `variables` | no | JSON Schema declaring variable **names**. The plugin stores no secret values; a person sets them in the dashboard and they are substituted into `${VAR}`. |

## What bites

- **Two manifest formats live side by side and they are not the same file.** An Agent Plugin carries `plugin.json` at the plugin root and packages skills and MCP servers; a Cursor Plugin carries `.cursor-plugin/plugin.json` and adds rules, agents, commands, hooks and variables. This provider writes the second. Validating our bytes against the first one's schema reports a false defect, which happened once and is recorded in the baseline.
- **A bare `SKILL.md` at the plugin root turns the whole plugin into a single skill** -- but only when there is no `skills/` directory and no manifest `skills` key. A file dropped at the root therefore changes what the plugin *is*, silently, depending on what else is beside it.
- `variables` declares names, never values. A secret written into a plugin manifest is a secret committed to a repository.

## The same file on the other harnesses

Generated from the same rows as the section above, for every harness in this estate that routes this kind. `—` means the product's own reference does not name the field, and **dropped** means it names it as one it accepts and does not act on.

| field | `claude` | `grok` | `cursor` | `antigravity` |
|---|---|---|---|---|
| `name` | **required** | yes | **required** | yes |
| `displayName` | yes | — | — | — |
| `description` | yes | yes | yes | — |
| `version` | yes | — | yes | — |
| `author` | yes | — | yes | — |
| `skills` | yes | yes | yes | — |
| `commands` | yes | yes | yes | — |
| `agents` | yes | yes | yes | — |
| `hooks` | yes | yes | yes | — |
| `mcpServers` | yes | yes | yes | — |
| `outputStyles` | yes | — | — | — |
| `lspServers` | yes | yes | — | — |
| `userConfig` | yes | — | — | — |
| `homepage` | yes | — | yes | — |
| `repository` | yes | — | yes | — |
| `license` | yes | — | yes | — |
| `keywords` | yes | — | yes | — |
| `metadata` | yes | — | — | — |
| `defaultEnabled` | yes | — | — | — |
| `dependencies` | yes | — | — | — |
| `logo` | — | — | yes | — |
| `rules` | — | — | yes | — |
| `variables` | — | — | yes | — |

**The part that travels**: `name`. Everything else is a bet on one product.

**The part that does not, and says nothing when it does not**: a field absent from a column is not rejected there -- it is read past. Nothing warns, no run fails, and the component behaves differently with the same bytes. Where the field was carrying a restriction, the restriction is simply gone. Check the column before relying on one.

## Before you ship one

- **The surface is declared, so the component is a promise.** Every kind   this provider declares is a promise of a rollback. A component written   to a path the declaration does not carry is installed by nobody and   removed by nobody.
- **Name it once.** Where the product derives identity from the directory   or the filename, the frontmatter `name` is either redundant or a second   place to be wrong. Keep them equal.
- **Read it back.** After an install, look at the file where the product   reads it, not at the step that put it there.
