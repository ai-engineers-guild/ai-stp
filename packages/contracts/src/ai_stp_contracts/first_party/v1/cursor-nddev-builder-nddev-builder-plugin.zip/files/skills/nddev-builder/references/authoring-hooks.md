# Writing a hook for this harness

Generated from the vendor's own reference and the pinned binary. Do not edit: the next render overwrites it, and a correction belongs in the source this file is derived from.

**Where it goes**: `~/.cursor/hooks.json/hooks.json`

**Decided by**: https://cursor.com/docs/hooks

**How it runs**: Fired by the product on the named event.

## Manifest

| key | required | what it does |
|---|---|---|
| `hooks` | **yes** | An object keyed by event name. Each value is an array of entries, and each entry carries a `command`. |
| `matcher` | no | Per-entry regular expression narrowing which invocations fire the hook, e.g. `rm|curl|wget` on `beforeShellExecution`. |

## Events

`sessionStart`  `sessionEnd`  `preToolUse`  `postToolUse`  `postToolUseFailure`  `subagentStart`  `subagentStop`  `beforeShellExecution`  `afterShellExecution`  `beforeMCPExecution`  `afterMCPExecution`  `beforeReadFile`  `afterFileEdit`  `beforeSubmitPrompt`  `preCompact`  `stop`  `afterAgentResponse`  `afterAgentThought`  `beforeTabFileRead`  `afterTabFileEdit`  `workspaceOpen`

## What bites

- **A hook is a program that runs on somebody else's schedule.** A setup that installs one installs execution, not a document, and the `command` is resolved relative to wherever the product decides. Treat adding one as a decision a person makes.
- The user-level file exists and the baseline says so: this row was corrected on 2026-08-28 from *"a plugin manifest key, not a directory under the config home"*.

## Before you ship one

- **The surface is declared, so the component is a promise.** Every kind   this provider declares is a promise of a rollback. A component written   to a path the declaration does not carry is installed by nobody and   removed by nobody.
- **Name it once.** Where the product derives identity from the directory   or the filename, the frontmatter `name` is either redundant or a second   place to be wrong. Keep them equal.
- **Read it back.** After an install, look at the file where the product   reads it, not at the step that put it there.
