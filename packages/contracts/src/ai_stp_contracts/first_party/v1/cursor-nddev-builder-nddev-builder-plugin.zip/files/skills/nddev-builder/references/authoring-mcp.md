# Writing an MCP server for this harness

Generated from the vendor's own reference and the pinned binary. Do not edit: the next render overwrites it, and a correction belongs in the source this file is derived from.

**Where it goes**: `~/.cursor/mcp.json/mcp.json`

**Decided by**: https://cursor.com/docs/mcp

**How it runs**: Discovered automatically at the plugin root; name it in the manifest's `mcpServers` only for a custom path or an inline config.

## Manifest

| key | required | what it does |
|---|---|---|
| `mcpServers` | **yes** | An object keyed by server name. Each entry names a `command` with `args` and `env`, or a `url`. |
| `type` | no | Transport, on the Agent Plugin schema. A Cursor Plugin infers it from whether `command` or `url` is present. |
| `env` | no | Environment for a stdio server. `${VAR}` here is a **plugin variable**, not a shell expansion and not `${env:...}`. |

## What bites

- **`${...}` is not shell here.** A plugin variable placeholder is declared under `variables` in the manifest and filled from the dashboard. Writing `${env:HOME}` produces a literal, not a value.
- Plugin-managed MCP config is read-only in the dashboard, so a person cannot repair a server this provider installed from the UI -- they have to change the setup.

## The same file on the other harnesses

Generated from the same rows as the section above, for every harness in this estate that routes this kind. `—` means the product's own reference does not name the field, and **dropped** means it names it as one it accepts and does not act on.

| field | `cursor` | `antigravity` |
|---|---|---|
| `mcpServers` | **required** | — |
| `type` | yes | — |
| `env` | yes | yes |
| `command` | — | **required** |
| `serverUrl` | — | **required** |
| `args` | — | yes |
| `cwd` | — | yes |
| `headers` | — | yes |
| `authProviderType` | — | yes |
| `oauth` | — | yes |
| `disabled` | — | yes |
| `disabledTools` | — | yes |

**The part that travels**: `env`. Everything else is a bet on one product.

**The part that does not, and says nothing when it does not**: a field absent from a column is not rejected there -- it is read past. Nothing warns, no run fails, and the component behaves differently with the same bytes. Where the field was carrying a restriction, the restriction is simply gone. Check the column before relying on one.

## Before you ship one

- **The surface is declared, so the component is a promise.** Every kind   this provider declares is a promise of a rollback. A component written   to a path the declaration does not carry is installed by nobody and   removed by nobody.
- **Name it once.** Where the product derives identity from the directory   or the filename, the frontmatter `name` is either redundant or a second   place to be wrong. Keep them equal.
- **Read it back.** After an install, look at the file where the product   reads it, not at the step that put it there.
