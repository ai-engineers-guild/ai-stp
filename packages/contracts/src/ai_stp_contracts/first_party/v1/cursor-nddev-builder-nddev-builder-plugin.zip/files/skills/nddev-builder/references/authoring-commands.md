# Writing a command for this harness

Generated from the vendor's own reference and the pinned binary. Do not edit: the next render overwrites it, and a correction belongs in the source this file is derived from.

**Where it goes**: `~/.cursor/commands/<name>.md`

**Decided by**: https://cursor.com/docs/reference/plugins

**How it runs**: Typed as `/<name>` in chat.

## Frontmatter

| field | required | what it does |
|---|---|---|
| `name` | no | Command identifier, lowercase kebab-case. |
| `description` | no | What the command does. |

## What bites

- **Four extensions, not one.** `commands/` admits `.md`, `.mdc`, `.markdown` and `.txt`, so a file this provider does not recognise may still be a live command to the product.
- Frontmatter is optional here and required on skills, which is the kind of asymmetry that survives a copy-paste between the two directories without anything complaining.

## The same file on the other harnesses

Generated from the same rows as the section above, for every harness in this estate that routes this kind. `—` means the product's own reference does not name the field, and **dropped** means it names it as one it accepts and does not act on.

| field | `claude` | `codex` | `pi` | `opencode` | `cursor` | `antigravity` |
|---|---|---|---|---|---|---|
| `description` | yes | yes | yes | yes | yes | yes |
| `argument-hint` | yes | yes | yes | — | — | — |
| `name` | **dropped** | — | — | — | yes | — |
| `paths` | **dropped** | — | — | — | — | — |
| `agent` | — | — | — | yes | — | — |
| `model` | — | — | — | yes | — | — |
| `subtask` | — | — | — | yes | — | — |
| `title` | — | — | — | — | — | yes |

**The part that travels**: `description`. Everything else is a bet on one product.

**The part that does not, and says nothing when it does not**: a field absent from a column is not rejected there -- it is read past. Nothing warns, no run fails, and the component behaves differently with the same bytes. Where the field was carrying a restriction, the restriction is simply gone. Check the column before relying on one.

## Before you ship one

- **The surface is declared, so the component is a promise.** Every kind   this provider declares is a promise of a rollback. A component written   to a path the declaration does not carry is installed by nobody and   removed by nobody.
- **Name it once.** Where the product derives identity from the directory   or the filename, the frontmatter `name` is either redundant or a second   place to be wrong. Keep them equal.
- **Read it back.** After an install, look at the file where the product   reads it, not at the step that put it there.
