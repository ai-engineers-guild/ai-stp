# Writing a skill for this harness

Generated from the vendor's own reference and the pinned binary. Do not edit: the next render overwrites it, and a correction belongs in the source this file is derived from.

**Where it goes**: `~/.cursor/skills/<name>/SKILL.md`

**Decided by**: https://cursor.com/docs/skills

**How it runs**: Applied automatically when the agent judges it relevant, or typed as `/<name>` in chat, which attaches it to one message. `Option`/`Alt`+`Enter` keeps it on as a Custom Mode for the session.

## Frontmatter

| field | required | what it does |
|---|---|---|
| `name` | **yes** | Skill identifier. Lowercase letters, numbers and hyphens only, and it **must match the parent folder name**. |
| `description` | **yes** | What the skill does and when to use it. The agent reads it to decide relevance. |
| `paths` | no | Glob patterns scoping the skill to matching files. A comma-separated string or a list. When set, the skill is surfaced only while the agent works on files that match. |
| `disable-model-invocation` | no | When `true` the skill is included only when typed as `/skill-name`; the agent will not apply it from context. |
| `icon` | no | Badge icon when the skill backs a Custom Mode. |
| `color` | no | Badge colour when the skill backs a Custom Mode. One of `default`, `green`, `cyan`, `blue`, `purple`, `magenta`, `orange`, `yellow`, `red`, `brand`. |
| `metadata` | no | Arbitrary key-value mapping. |

## What bites

- **`name` must equal the folder name**, which is the one product here that says so outright. The estate's usual advice -- name it once, and keep the frontmatter and the directory equal -- is a requirement on this harness rather than a courtesy.
- **Discovery is recursive and a category folder is not identity.** Cursor walks the skills root and picks up every `SKILL.md` beneath it; the skill's identity comes from the directory holding that file, not from any parent. So a tidy `skills/authoring/nddev-builder/` and a flat `skills/nddev-builder/` are the same skill under different paths, and only the leaf name is load-bearing.
- A skill with valid frontmatter can back a Custom Mode, which keeps it in context for a whole session. That is a wider grant than a single message and it is available to any skill this provider installs.

## The same file on the other harnesses

Generated from the same rows as the section above, for every harness in this estate that routes this kind. `—` means the product's own reference does not name the field, and **dropped** means it names it as one it accepts and does not act on.

| field | `claude` | `grok` | `pi` | `opencode` | `cursor` | `antigravity` |
|---|---|---|---|---|---|---|
| `name` | yes | yes | **required** | **required** | **required** | yes |
| `description` | yes | yes | **required** | **required** | **required** | **required** |
| `argument-hint` | yes | yes | — | — | — | — |
| `arguments` | yes | — | — | — | — | — |
| `allowed-tools` | yes | **dropped** | yes | — | — | — |
| `disallowed-tools` | yes | — | — | — | — | — |
| `disable-model-invocation` | yes | yes | yes | — | yes | — |
| `user-invocable` | yes | yes | — | — | — | — |
| `model` | yes | **dropped** | — | — | — | — |
| `effort` | yes | **dropped** | — | — | — | — |
| `context` | yes | — | — | — | — | — |
| `agent` | yes | — | — | — | — | — |
| `background` | yes | — | — | — | — | — |
| `hooks` | yes | — | — | — | — | — |
| `paths` | yes | yes | — | — | yes | — |
| `shell` | yes | — | — | — | — | — |
| `metadata` | yes | yes | yes | yes | yes | — |
| `license` | yes | **dropped** | yes | yes | — | — |
| `compatibility` | yes | **dropped** | yes | yes | — | — |
| `when_to_use` | yes | — | — | — | — | — |
| `when-to-use` | — | yes | — | — | — | — |
| `icon` | — | — | — | — | yes | — |
| `color` | — | — | — | — | yes | — |

**The part that travels**: `name`, `description`. Everything else is a bet on one product.

**The part that does not, and says nothing when it does not**: a field absent from a column is not rejected there -- it is read past. Nothing warns, no run fails, and the component behaves differently with the same bytes. Where the field was carrying a restriction, the restriction is simply gone. Check the column before relying on one.

## Before you ship one

- **The surface is declared, so the component is a promise.** Every kind   this provider declares is a promise of a rollback. A component written   to a path the declaration does not carry is installed by nobody and   removed by nobody.
- **Name it once.** Where the product derives identity from the directory   or the filename, the frontmatter `name` is either redundant or a second   place to be wrong. Keep them equal.
- **Read it back.** After an install, look at the file where the product   reads it, not at the step that put it there.
