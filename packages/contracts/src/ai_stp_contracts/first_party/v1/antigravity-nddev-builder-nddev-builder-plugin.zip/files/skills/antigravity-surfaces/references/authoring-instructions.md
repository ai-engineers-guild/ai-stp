# Writing this harness's instruction file

Generated from `references/antigravity-baseline.json`. Do not edit:
the next render overwrites it, and the baseline is where a correction
belongs.

## Where it goes

`~/.gemini/config/rules/` -- a **directory**, one file per rule

Decided by: measured from the 1.1.22 artifact's own embedded reference, digest verified before reading, 2026-08-29

## What the record says about it

**A customization element this declaration was missing, not a surface the product lacks.** The binary's embedded reference lists what exists *within any of the customization roots*: *"1. Skills (Directories) … 2. **Rules** (Markdown Files): Location: `rules/` (relative to the customization root) or standalone `GEMINI.md`/`AGENTS.md` files … 3. Plugins (Directories) … 4. MCP Servers (`mcp_config.json`) and Hooks (`hooks.json`)."* Four of those five were declared here and `rules/` was not.

The record said the opposite -- *the product documents instruction only at workspace scope* -- which was a negative taken from the pages that happened to be read. The same comment had already been wrong about `command`, corrected 2026-08-28 on `config/global_workflows`. Twice in one declaration, both times the evidence was in a binary this repository had already downloaded.

**`AGENTS.md` is the product's own recommended shape**, from the same reference: *"Placing a consolidated `AGENTS.md` (or `GEMINI.md`) file under `rules/` … is recommended over separate rule files."* The elided clause is the vendor's own example of one root; it is left out because a reader here would take an example path for a document these setups carry, and they carry it elsewhere.

**Where the setups actually write it, and why not here.** They write a consolidated `AGENTS.md` under a `rules/` directory at the *plugin* customization root -- `config/plugins/{plugin_name}/rules/AGENTS.md`, named as a class because this note is carried into every setup and each names its own plugin. That is the same recommendation applied to a different one of the roots the reference lists, and the choice is argued in each `plugin.json`: a plugin's skills, rules, hooks and MCP servers are ingested together when it is enabled, and `config/plugins` is a surface that routes today. `config/rules` is owned and declared, and a setup writing there as well would load the same floor twice.

Searched with a control: `AGENTS.md` appears ten times in the pinned bytes and `GEMINI.md` eight, while an invented `nddev-invented-instruction-file.md` appears zero -- so the search discriminates. `bytes` and not `ran`: starting this product needs a credential, and the credential-free subcommands report nothing about resolved rules.

**Owned, declared, and waiting on the consumer's route.** The `instruction` kind is declared here. An earlier revision of this note said the opposite and gave a measurement for it -- *adding the kind was tried and antigravity went from 29 passing cases to REFUSED, 30 cases* -- and that measurement was our own instrument misreading the checker.

`declared_route_is_compilable:instruction` carries `subject: consumer`, and the checker's `conforms` is computed over provider-subject cases alone, by an explicit decision documented in its source: a provider declaring a kind the compiler has no route for *"has satisfied every obligation v3 places on it; the gap is ours, and calling it non-conformance would name the wrong party in the one field people read"*. With the kind declared the checker answers `conforms: true` with zero provider-subject failures. A summary that counted every failed case regardless of subject printed REFUSED over a provider the checker had just passed -- and this note then recorded that as a fact about the protocol, which is how a bad reading hardens into a record. Fixed, with a control that plants the same mis-count.

Declaring the kind changes nothing a user sees while the consumer's `PROVIDER_RULES` has no `instruction` row for this harness: composition still refuses early with `native_surface_lost`, which is the honest place for it. What it does change is the ordering -- the provider is no longer on the critical path, so the route works the moment the consumer lands it, with no window in which an instruction composes and is refused late.

## Where the other harnesses keep theirs

| harness | path | shape |
|---|---|---|
| **this one** | `config/rules` | directory |
| `claude` | `CLAUDE.md` | file |
| `codex` | `AGENTS.md` | file |
| `cursor` | `rules` | directory |
| `grok` | `AGENTS.md` | file |
| `opencode` | `AGENTS.md` | file |
| `pi` | `AGENTS.md` | file |

**They are not interchangeable, and the difference is not only the
name.** One of the seven takes a *directory* of rules rather than a
single document, so a file moved between the two is not a rename.

**Some products read a neighbour's.** `references/surfaces.md` records
every such cross-read this estate has measured, on the declined rows:
a file written for one product can change what a second one sees, and
removing a setup can change what a third one sees. That is a property
of the products, not of this program, and it is the reason the declined
list is worth reading before writing here.

## Before you write one

- **This file is the floor, not the ceiling.** A repository's own
  instructions sit above it; write what is true everywhere and leave
  the rest to the project.
- **Read it back where the product reads it**, not where the install
  put it. Several of these products resolve a home through an override
  chain, and the two are not always the same directory.

