# Writing a hook for this harness

Generated from the vendor's own reference and the pinned binary. Do not edit: the next render overwrites it, and a correction belongs in the source this file is derived from.

**Where it goes**: `~/.gemini/config/hooks.json`

**Decided by**: https://antigravity.google/docs/hooks

**How it runs**: The file maps hook names to arrays of event configurations.

## Frontmatter

| field | required | what it does |
|---|---|---|
| `command` | **yes** | The shell command to run. |
| `type` | no | Defaults to `command`. |
| `timeout` | no | Seconds. Defaults to 30. |

## Events

`PreToolUse`  `PostToolUse`  `PreInvocation`  `PostInvocation`  `Stop`

## What bites

- **Five events, against eleven and fourteen on the two other hook-routing harnesses here.** `PreInvocation` and `PostInvocation` fire around the model call and have no counterpart on either of them, and there is no session-lifecycle or compaction event at all. A hook ported in from one of those is likely to be registered under a name this product never fires -- and nothing reports an event name it does not know.
- **The script contract is JSON in, JSON out, camelCase both ways.** Every event carries `conversationId`, `workspacePaths`, `transcriptPath`, `artifactDirectoryPath` and `modelName`; `PreToolUse` adds `toolCall` (with `name` and `args`) and `stepIdx`; `Stop` adds `executionNum`, `terminationReason` and `fullyIdle`.
- The vendor documents no exit-code contract and no environment variables. Both are documented on the other two harnesses, so a hook that signals a decision by exiting non-zero is relying on something this product has not promised.

## The same file on the other harnesses

Generated from the same rows as the section above, for every harness in this estate that routes this kind. `—` means the product's own reference does not name the field, and **dropped** means it names it as one it accepts and does not act on.

| field | `codex` | `grok` | `antigravity` |
|---|---|---|---|
| `matcher` | yes | yes | — |
| `type` | yes | yes | yes |
| `command` | yes | yes | **required** |
| `commandWindows` | yes | — | — |
| `timeout` | yes | yes | yes |
| `statusMessage` | yes | — | — |
| `additionalContextLimit` | yes | — | — |
| `async` | yes | — | — |
| `server` | yes | — | — |
| `tool` | yes | — | — |
| `input` | yes | — | — |
| `url` | — | yes | — |

**The part that travels**: `type`, `command`, `timeout`. Everything else is a bet on one product.

**The part that does not, and says nothing when it does not**: a field absent from a column is not rejected there -- it is read past. Nothing warns, no run fails, and the component behaves differently with the same bytes. Where the field was carrying a restriction, the restriction is simply gone. Check the column before relying on one.

## Before you ship one

- **The surface is declared, so the component is a promise.** Every kind   this provider declares is a promise of a rollback. A component written   to a path the declaration does not carry is installed by nobody and   removed by nobody.
- **Name it once.** Where the product derives identity from the directory   or the filename, the frontmatter `name` is either redundant or a second   place to be wrong. Keep them equal.
- **Read it back.** After an install, look at the file where the product   reads it, not at the step that put it there.
