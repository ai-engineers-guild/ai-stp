# Writing an MCP server for this harness

Generated from the vendor's own reference and the pinned binary. Do not edit: the next render overwrites it, and a correction belongs in the source this file is derived from.

**Where it goes**: `~/.gemini/config/mcp_config.json`

**Decided by**: https://antigravity.google/docs/mcp

**How it runs**: Servers live under a top-level `mcpServers` object keyed by name.

## Manifest

| key | required | what it does |
|---|---|---|
| `command` | **yes** | Executable for a `stdio` server. One of this or `serverUrl` is required. |
| `serverUrl` | **yes** | URL for a remote Streamable HTTP or SSE server. |
| `args` | no | Arguments for a stdio server. |
| `env` | no | Environment for the stdio process. |
| `cwd` | no | Working directory for a stdio server. |
| `headers` | no | HTTP headers for a remote server. |
| `authProviderType` | no | Supports `google_credentials`. |
| `oauth` | no | Object with `clientId` and `clientSecret`. |
| `disabled` | no | Turn a server off without removing its configuration. |
| `disabledTools` | no | Tool names withheld from the model. |

## What bites

- **This is the one kind in this estate whose file may hold credentials.** `oauth` takes a `clientSecret` and `env` takes whatever a server needs. A setup that carries this file carries whatever is in it, and a backup slot holding it puts those bytes on disk a second time. Ship servers that read their secrets from the environment, and keep the secrets out of what this provider captures.
- `disabled` is the right way to turn a server off. Deleting the entry loses the configuration, and a restore then returns a file that disagrees with what the person meant.

## The same file on the other harnesses

Generated from the same rows as the section above, for every harness in this estate that routes this kind. `—` means the product's own reference does not name the field, and **dropped** means it names it as one it accepts and does not act on.

| field | `cursor` | `antigravity` |
|---|---|---|
| `mcpServers` | **required** | — |
| `type` | yes | — |
| `env` | yes | yes |
| `command` | — | **required** |
| `serverUrl` | — | **required** |
| `args` | — | yes |
| `cwd` | — | yes |
| `headers` | — | yes |
| `authProviderType` | — | yes |
| `oauth` | — | yes |
| `disabled` | — | yes |
| `disabledTools` | — | yes |

**The part that travels**: `env`. Everything else is a bet on one product.

**The part that does not, and says nothing when it does not**: a field absent from a column is not rejected there -- it is read past. Nothing warns, no run fails, and the component behaves differently with the same bytes. Where the field was carrying a restriction, the restriction is simply gone. Check the column before relying on one.

## Before you ship one

- **The surface is declared, so the component is a promise.** Every kind   this provider declares is a promise of a rollback. A component written   to a path the declaration does not carry is installed by nobody and   removed by nobody.
- **Name it once.** Where the product derives identity from the directory   or the filename, the frontmatter `name` is either redundant or a second   place to be wrong. Keep them equal.
- **Read it back.** After an install, look at the file where the product   reads it, not at the step that put it there.
