# The scoped target this harness owns

## `target_scope: user_root`, rooted at `~/.agents`

**`~/.agents` is not this product's configuration home.** It is a
different target, reached by a consumer naming the scope on the
request, and every path below is relative to that root rather
than to the home -- writing the root into the path again would
nest it twice, which is a mistake this estate has made and
shipped.

| path | routes | decided by | exercised by |
|---|---|---|---|
| `skills` | skill | measured by running the 1.0.13 binary with `grok inspect` against a temporary HOME | **ran it** |
### `skills`, as measured

**Run, not read.** The pinned `grok-1.0.13-linux-x86_64` was fetched, its digest checked against the artifact table, and driven with `grok inspect` -- *Show the configuration Grok discovers for this directory*, which needs no credential. With a `SKILL.md` at `$HOME/.agents/skills/nddev-user-root-probe/` it reports:

```
  Skills (1)
  └ nddev-user-root-probe  user
```

-- discovered, and at the **user** tier, which is the half the embedded reference's tier table asserted and a run confirms.

**With a control.** A second skill at `$HOME/.agents-not-a-root/skills/` -- a sibling root no page names -- is absent: the count is 1, not 2. Without it, "the probe was found" could not be told from "the product scans `$HOME`".

The one root in this estate that belongs to a convention rather than to a product. `$HOME/.agents/skills` is a *sibling* of this product's configuration home, not a child, so nothing declared against this provider's own target can reach it -- that is what `user_root` exists for.

**Owning a shared root, and the reason this record used to decline it.** Five of the seven products read this root, and the decline said: *a namespace is removed whole, so a second declaration would make either provider's remove take the other's skills.* That sentence was true when it was written and stopped being true when `written_paths` shipped -- `remove` under this scope takes the files this provider recorded writing and refuses rather than widening when it cannot read the record, and each harness carries its own state file, so they coexist under one root. The reason was not re-read when the thing it described changed.

Relative to this scope's own root the path is `skills`, not `.agents/skills`: the root is what the scope names, and writing it into the path again would put the skills at `~/.agents/.agents/skills`.

**Re-asked at 1.0.18 on 2026-09-04.** Digest-verified `grok-1.0.18-linux-x86_64` (`sha256:42f6efb4…`), `grok inspect --json` in a temporary HOME: the same `skills/` probe is still `source.type=user`.


Considered under this scope and not owned:

- **`commands`** — Grok 1.0.18 discovers `~/.agents/commands/<name>.md` as a **skill**, in the same `skills` array as `~/.agents/skills/<name>/SKILL.md`. Measured with `grok inspect --json` against a temporary HOME on the digest-verified `grok-1.0.18-linux-x86_64`: `nddev-agents-command.md` appeared as `skills[].name=nddev-agents-command` with `source.type=user`; a control file under `$HOME/.agents-not-a-root/commands/` did not. The owned `skills` surface already routes the skill kind under this scope. Owning `commands` too would put one kind on two surfaces, which `harness_runtime::surfaces` refuses. This provider writes user-root skills only under `skills/`. The vendor page names both directories; the run is what decided they are one kind.


**A complete setup may include these scoped components.** Each
provider request still reaches one root. The consumer coordinates
the roots with `ai-stp install transaction plan`, exact digest
approval, apply and recovery. A shipped configuration-home preset
cannot reach this root by nesting a path inside its home payload.
Declare the component's actual scope and bind the matching root
explicitly in the transaction.

**The root is shared, and that changes what removal means.** Several
products read it. Under this scope `remove`, the backup and a
restore act on the files this provider recorded writing rather than
on the directory whole, so a neighbour's files are never captured
into a slot here and never reverted out of one.

