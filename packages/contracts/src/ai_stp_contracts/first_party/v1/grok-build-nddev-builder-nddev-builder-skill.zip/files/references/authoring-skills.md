# Writing a skill for this harness

Generated from the vendor's own reference and the pinned binary. Do not edit: the next render overwrites it, and a correction belongs in the source this file is derived from.

**Where it goes**: `~/.grok/skills/<name>/SKILL.md`

**Decided by**: https://docs.x.ai/build/features/skills-plugins-marketplaces

**How it runs**: Any enabled skill with `user-invocable: true` appears as `/<name>`.

## Frontmatter

| field | required | what it does |
|---|---|---|
| `name` | no | Defaults to the directory name. |
| `description` | no | Purpose and usage guidance. First body paragraph if omitted. |
| `when-to-use` | no | Extra trigger phrases. Alias: `when_to_use`. |
| `paths` | no | Gitignore-style globs for conditional visibility. |
| `argument-hint` | no | Autocomplete text for the slash command. |
| `user-invocable` | no | Show as a slash command. Default `true`. Only the literal `true` counts; `yes` is false. |
| `disable-model-invocation` | no | Manual invocation only. |
| `metadata` | no | String map, with `author` and `short-description`. |
| `model` | — | **Accepted and ignored.** The product names it as a field it does not act on. |
| `effort` | — | **Accepted and ignored.** The product names it as a field it does not act on. |
| `license` | — | **Accepted and ignored.** The product names it as a field it does not act on. |
| `compatibility` | — | **Accepted and ignored.** The product names it as a field it does not act on. |
| `allowed-tools` | — | **Accepted and ignored.** The product names it as a field it does not act on. |

## What bites

- The product's own reference states the spelling rule directly: *"Multi-word frontmatter keys use kebab-case (single-word keys like `model` are written as-is)."*
- **`allowed-tools` is named and does nothing.** The 2026-09-04 vendor page: *"Does not grant or restrict tools."* It accepts a YAML list or a comma/space-separated string and is dropped the same way as `model`. A skill that relies on it for a permission grant on Claude does not get that grant here.
- This product also reads another vendor's skills directory. That is recorded in `surfaces` under what is deliberately not owned, and it means removing a different harness's setup changes what this one sees.
- `~/.agents/commands/<name>.md` is discovered as a skill, not as a command kind. Measured on grok 1.0.18 with `inspect --json`. This provider writes user-root skills under `skills/` only.

## The same file on the other harnesses

Generated from the same rows as the section above, for every harness in this estate that routes this kind. `—` means the product's own reference does not name the field, and **dropped** means it names it as one it accepts and does not act on.

| field | `claude` | `grok` | `pi` | `opencode` | `cursor` | `antigravity` |
|---|---|---|---|---|---|---|
| `name` | yes | yes | **required** | **required** | **required** | yes |
| `description` | yes | yes | **required** | **required** | **required** | **required** |
| `argument-hint` | yes | yes | — | — | — | — |
| `arguments` | yes | — | — | — | — | — |
| `allowed-tools` | yes | **dropped** | yes | — | — | — |
| `disallowed-tools` | yes | — | — | — | — | — |
| `disable-model-invocation` | yes | yes | yes | — | yes | — |
| `user-invocable` | yes | yes | — | — | — | — |
| `model` | yes | **dropped** | — | — | — | — |
| `effort` | yes | **dropped** | — | — | — | — |
| `context` | yes | — | — | — | — | — |
| `agent` | yes | — | — | — | — | — |
| `background` | yes | — | — | — | — | — |
| `hooks` | yes | — | — | — | — | — |
| `paths` | yes | yes | — | — | yes | — |
| `shell` | yes | — | — | — | — | — |
| `metadata` | yes | yes | yes | yes | yes | — |
| `license` | yes | **dropped** | yes | yes | — | — |
| `compatibility` | yes | **dropped** | yes | yes | — | — |
| `when_to_use` | yes | — | — | — | — | — |
| `when-to-use` | — | yes | — | — | — | — |
| `icon` | — | — | — | — | yes | — |
| `color` | — | — | — | — | yes | — |

**The part that travels**: `name`, `description`. Everything else is a bet on one product.

**The part that does not, and says nothing when it does not**: a field absent from a column is not rejected there -- it is read past. Nothing warns, no run fails, and the component behaves differently with the same bytes. Where the field was carrying a restriction, the restriction is simply gone. Check the column before relying on one.

## Before you ship one

- **The surface is declared, so the component is a promise.** Every kind   this provider declares is a promise of a rollback. A component written   to a path the declaration does not carry is installed by nobody and   removed by nobody.
- **Name it once.** Where the product derives identity from the directory   or the filename, the frontmatter `name` is either redundant or a second   place to be wrong. Keep them equal.
- **Read it back.** After an install, look at the file where the product   reads it, not at the step that put it there.
