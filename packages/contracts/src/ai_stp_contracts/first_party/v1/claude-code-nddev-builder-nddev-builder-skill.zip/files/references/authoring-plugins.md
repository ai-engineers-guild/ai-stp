# Writing a plugin for this harness

Generated from the vendor's own reference and the pinned binary. Do not edit: the next render overwrites it, and a correction belongs in the source this file is derived from.

**Where it goes**: `~/.claude/skills/<name>/.claude-plugin/plugin.json`

**Decided by**: https://code.claude.com/docs/en/plugins-reference

**How it runs**: A folder under a skills directory carrying this manifest loads as `<name>@skills-dir` on the next session -- no marketplace, no install step, and at personal scope no trust gate. The manifest is what tells the product a folder is a plugin rather than a skill: `{name}/SKILL.md` with no manifest is a skill named after its directory, and the same folder carrying `.claude-plugin/plugin.json` is a plugin that can bundle its own skills, agents and hooks.

## Manifest

| key | required | what it does |
|---|---|---|
| `name` | **yes** | Unique identifier, kebab-case. Namespaces the plugin's skills. |
| `displayName` | no | Human-readable name shown in the plugin manager; falls back to `name`. |
| `description` | no | What the plugin is for. Shown when browsing or installing. |
| `version` | no | Semantic version. Users receive updates only when it is bumped. |
| `author` | no | Object with `name`, `email` and `url`. |
| `skills` | no | Extra skill directories holding `<name>/SKILL.md`, added to the default `skills/`. |
| `commands` | no | Flat `.md` skill files or directories; replaces the default `commands/`. |
| `agents` | no | Agent markdown files; replaces the default `agents/`. |
| `hooks` | no | Hook config paths, or the configuration inline. |
| `mcpServers` | no | MCP server config paths, or the configuration inline. |
| `outputStyles` | no | Custom output-style files or directories; replaces the default `output-styles/`. |
| `lspServers` | no | Language-server configs for code intelligence, as a path, array, or inline object. |
| `userConfig` | no | Values Claude Code prompts for at enable time. Substituted as `${user_config.KEY}` in MCP/LSP/hook configs, not in a monitor or shell-form hook command. |
| `homepage` | no | Documentation URL. Metadata only. |
| `repository` | no | Source-code URL. Metadata only. |
| `license` | no | License identifier, e.g. MIT. Metadata only. |
| `keywords` | no | Discovery tags. Metadata only. |
| `metadata` | no | Free-form object Claude Code does not read. Before v2.1.222 this key was treated as unrecognised. |
| `defaultEnabled` | no | Whether it starts enabled before the user chooses. Defaults to true. |
| `dependencies` | no | Other plugins this one needs, optionally with a semver constraint. |

## What bites

- Only `plugin.json` goes inside `.claude-plugin/`. Every other directory -- `skills/`, `commands/`, `agents/`, `hooks/`, `bin/`, `scripts/` -- sits at the plugin root, and the plugin root is never the configuration home itself.
- Claude Code 2.1.259 adds machine-readable validation: run `claude plugin validate <plugin-root> --json` before the repository gate. It validates the native plugin shape; the setup-system gate still proves ownership, rollback and cross-harness constraints.
- **`themes` and `monitors` are experimental.** Declare them under `experimental.themes` and `experimental.monitors`; a top-level key still loads but `claude plugin validate` warns, and a later release will require the nested form. Unrecognised top-level fields are warnings, not load errors.

## The same file on the other harnesses

Generated from the same rows as the section above, for every harness in this estate that routes this kind. `—` means the product's own reference does not name the field, and **dropped** means it names it as one it accepts and does not act on.

| field | `claude` | `grok` | `cursor` | `antigravity` |
|---|---|---|---|---|
| `name` | **required** | yes | **required** | yes |
| `displayName` | yes | — | — | — |
| `description` | yes | yes | yes | — |
| `version` | yes | — | yes | — |
| `author` | yes | — | yes | — |
| `skills` | yes | yes | yes | — |
| `commands` | yes | yes | yes | — |
| `agents` | yes | yes | yes | — |
| `hooks` | yes | yes | yes | — |
| `mcpServers` | yes | yes | yes | — |
| `outputStyles` | yes | — | — | — |
| `lspServers` | yes | yes | — | — |
| `userConfig` | yes | — | — | — |
| `homepage` | yes | — | yes | — |
| `repository` | yes | — | yes | — |
| `license` | yes | — | yes | — |
| `keywords` | yes | — | yes | — |
| `metadata` | yes | — | — | — |
| `defaultEnabled` | yes | — | — | — |
| `dependencies` | yes | — | — | — |
| `logo` | — | — | yes | — |
| `rules` | — | — | yes | — |
| `variables` | — | — | yes | — |

**The part that travels**: `name`. Everything else is a bet on one product.

**The part that does not, and says nothing when it does not**: a field absent from a column is not rejected there -- it is read past. Nothing warns, no run fails, and the component behaves differently with the same bytes. Where the field was carrying a restriction, the restriction is simply gone. Check the column before relying on one.

## Before you ship one

- **The surface is declared, so the component is a promise.** Every kind   this provider declares is a promise of a rollback. A component written   to a path the declaration does not carry is installed by nobody and   removed by nobody.
- **Name it once.** Where the product derives identity from the directory   or the filename, the frontmatter `name` is either redundant or a second   place to be wrong. Keep them equal.
- **Read it back.** After an install, look at the file where the product   reads it, not at the step that put it there.
