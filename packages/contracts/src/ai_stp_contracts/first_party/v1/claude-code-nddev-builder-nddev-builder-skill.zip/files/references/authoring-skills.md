# Writing a skill for this harness

Generated from the vendor's own reference and the pinned binary. Do not edit: the next render overwrites it, and a correction belongs in the source this file is derived from.

**Where it goes**: `~/.claude/skills/<name>/SKILL.md`

**Decided by**: https://code.claude.com/docs/en/skills

**How it runs**: `/<name>`, or Claude loads it when the description matches.

## Frontmatter

| field | required | what it does |
|---|---|---|
| `name` | no | Display name. Defaults to the directory name. |
| `description` | no | What it does and when to use it. Drives discovery. This and `when_to_use` are truncated together at 1,536 characters in the listing. |
| `argument-hint` | no | Autocomplete hint, e.g. `[issue-number]`. |
| `arguments` | no | Named positional arguments for `$name` substitution. |
| `allowed-tools` | no | Tools usable without asking for the invoking turn. |
| `disallowed-tools` | no | Tools removed from the pool while active. |
| `disable-model-invocation` | no | `true` keeps it manual-only. |
| `user-invocable` | no | `false` hides it from the `/` menu. |
| `model` | no | Model while active; `inherit` keeps the session's. |
| `effort` | no | `low` `medium` `high` `xhigh` `max`. |
| `context` | no | `fork` runs the skill in a subagent. |
| `agent` | no | Which subagent type, when `context: fork`. |
| `background` | no | Only with `context: fork`. |
| `hooks` | no | Hooks registered for the rest of the session. |
| `paths` | no | Globs limiting when the skill auto-loads. |
| `shell` | no | `bash` (default) or `powershell` for `!`command`` blocks. |
| `metadata` | no | Free-form map. Claude Code does not act on it. |
| `license` | no | Accepted, not acted on. |
| `compatibility` | no | Accepted, not acted on. |
| `when_to_use` | no | Extra context for when Claude should invoke it -- trigger phrases or example requests. **Appended to `description` in the skill listing and counted against the same 1,536-character cap**, so it is a share of one budget rather than a second field. |

## What bites

- **Commands and skills are the same mechanism here.** A file at `commands/<name>.md` and a skill at `skills/<name>/SKILL.md` both create `/<name>`, and they behave the same way. The skill form adds a directory for supporting files and frontmatter that controls who may invoke it.
- Boolean frontmatter fields accept `yes`/`no`/`on`/`off`/`1`/`0` in any letter case, in addition to `true`/`false`, since v2.1.218.

## The same file on the other harnesses

Generated from the same rows as the section above, for every harness in this estate that routes this kind. `—` means the product's own reference does not name the field, and **dropped** means it names it as one it accepts and does not act on.

| field | `claude` | `grok` | `pi` | `opencode` | `cursor` | `antigravity` |
|---|---|---|---|---|---|---|
| `name` | yes | yes | **required** | **required** | **required** | yes |
| `description` | yes | yes | **required** | **required** | **required** | **required** |
| `argument-hint` | yes | yes | — | — | — | — |
| `arguments` | yes | — | — | — | — | — |
| `allowed-tools` | yes | **dropped** | yes | — | — | — |
| `disallowed-tools` | yes | — | — | — | — | — |
| `disable-model-invocation` | yes | yes | yes | — | yes | — |
| `user-invocable` | yes | yes | — | — | — | — |
| `model` | yes | **dropped** | — | — | — | — |
| `effort` | yes | **dropped** | — | — | — | — |
| `context` | yes | — | — | — | — | — |
| `agent` | yes | — | — | — | — | — |
| `background` | yes | — | — | — | — | — |
| `hooks` | yes | — | — | — | — | — |
| `paths` | yes | yes | — | — | yes | — |
| `shell` | yes | — | — | — | — | — |
| `metadata` | yes | yes | yes | yes | yes | — |
| `license` | yes | **dropped** | yes | yes | — | — |
| `compatibility` | yes | **dropped** | yes | yes | — | — |
| `when_to_use` | yes | — | — | — | — | — |
| `when-to-use` | — | yes | — | — | — | — |
| `icon` | — | — | — | — | yes | — |
| `color` | — | — | — | — | yes | — |

**The part that travels**: `name`, `description`. Everything else is a bet on one product.

**The part that does not, and says nothing when it does not**: a field absent from a column is not rejected there -- it is read past. Nothing warns, no run fails, and the component behaves differently with the same bytes. Where the field was carrying a restriction, the restriction is simply gone. Check the column before relying on one.

## Before you ship one

- **The surface is declared, so the component is a promise.** Every kind   this provider declares is a promise of a rollback. A component written   to a path the declaration does not carry is installed by nobody and   removed by nobody.
- **Name it once.** Where the product derives identity from the directory   or the filename, the frontmatter `name` is either redundant or a second   place to be wrong. Keep them equal.
- **Read it back.** After an install, look at the file where the product   reads it, not at the step that put it there.
