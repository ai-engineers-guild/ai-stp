# Writing an agent for this harness

Generated from the vendor's own reference and the pinned binary. Do not edit: the next render overwrites it, and a correction belongs in the source this file is derived from.

**Where it goes**: `~/.claude/agents/<name>.md`

**Decided by**: https://code.claude.com/docs/en/sub-agents

**How it runs**: Claude delegates on the description; the body is the system prompt.

## Frontmatter

| field | required | what it does |
|---|---|---|
| `name` | **yes** | Lowercase and hyphens. Cannot contain `:`, which is reserved for plugin-scoped identifiers. |
| `description` | **yes** | When to delegate here. Claude reads this to decide. |
| `tools` | no | Allowlist, e.g. `Read, Grep, Glob, Bash`. |
| `disallowedTools` | no | Denylist, applied before `tools` resolves. |
| `model` | no | `inherit` by default. |
| `permissionMode` | no | `default` `acceptEdits` `auto` `dontAsk` `bypassPermissions` `plan` `manual`. |
| `maxTurns` | no | Positive integer; output is marked partial at the limit. |
| `skills` | no | Skills preloaded into the subagent's context. |
| `mcpServers` | no | Server names or inline definitions. |
| `hooks` | no | `PreToolUse`, `PostToolUse`, `Stop`. |
| `memory` | no | `user`, `project` or `local`. |
| `background` | no | Keep in background when asked for the foreground. |
| `effort` | no | Overrides the session level. |
| `isolation` | no | `worktree` runs it in a separate git worktree. |
| `color` | no | Display colour in the task list. |
| `initialPrompt` | no | Prepended when the agent runs as the main session. |

## What bites

- **The keys are camelCase here and kebab-case in a skill.** `disallowedTools` in an agent, `disallowed-tools` in a skill, in the same product. Copying a line between the two silently drops it.
- Descriptions are budgeted: the vendor asks that they total under 15,000 tokens across all custom subagents, because every one of them is in context at all times.
- **A plugin-shipped agent is a narrower file.** The vendor drops `hooks`, `mcpServers` and `permissionMode` on agents inside a plugin, for security. Those three still work on a user or project file under `agents/`. The only valid `isolation` value is `worktree`.

## The same file on the other harnesses

Generated from the same rows as the section above, for every harness in this estate that routes this kind. `—` means the product's own reference does not name the field, and **dropped** means it names it as one it accepts and does not act on.

| field | `claude` | `grok` | `opencode` | `antigravity` |
|---|---|---|---|---|
| `name` | **required** | — | yes | **required** |
| `description` | **required** | — | **required** | **required** |
| `tools` | yes | — | yes | yes |
| `disallowedTools` | yes | — | — | — |
| `model` | yes | — | yes | yes |
| `permissionMode` | yes | yes | — | — |
| `maxTurns` | yes | — | — | — |
| `skills` | yes | — | — | yes |
| `mcpServers` | yes | yes | — | yes |
| `hooks` | yes | yes | — | — |
| `memory` | yes | — | — | — |
| `background` | yes | — | — | — |
| `effort` | yes | — | — | — |
| `isolation` | yes | — | — | — |
| `color` | yes | — | yes | — |
| `initialPrompt` | yes | — | — | — |
| `mcpInheritance` | — | yes | — | — |
| `mode` | — | — | yes | — |
| `temperature` | — | — | yes | — |
| `top_p` | — | — | yes | — |
| `permission` | — | — | yes | — |
| `disable` | — | — | yes | — |
| `mainAgent` | — | — | — | yes |
| `subagent` | — | — | — | yes |
| `commandExecutionPolicy` | — | — | — | yes |

**The part that does not, and says nothing when it does not**: a field absent from a column is not rejected there -- it is read past. Nothing warns, no run fails, and the component behaves differently with the same bytes. Where the field was carrying a restriction, the restriction is simply gone. Check the column before relying on one.

## Before you ship one

- **The surface is declared, so the component is a promise.** Every kind   this provider declares is a promise of a rollback. A component written   to a path the declaration does not carry is installed by nobody and   removed by nobody.
- **Name it once.** Where the product derives identity from the directory   or the filename, the frontmatter `name` is either redundant or a second   place to be wrong. Keep them equal.
- **Read it back.** After an install, look at the file where the product   reads it, not at the step that put it there.
