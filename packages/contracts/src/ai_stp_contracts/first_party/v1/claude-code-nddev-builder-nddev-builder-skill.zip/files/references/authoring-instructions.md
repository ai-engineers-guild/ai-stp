# Writing this harness's instruction file

Generated from `references/claude-baseline.json`. Do not edit:
the next render overwrites it, and the baseline is where a correction
belongs.

## Where it goes

`~/.claude/CLAUDE.md`

Decided by: https://code.claude.com/docs/en/memory

## What the record says about it

Confirmed 2026-08-29 from the 2.1.251 artifact, whose bytes match this baseline's own sha256: the product carries `.claude/CLAUDE.md` as a literal, 9 time(s), joined to the home its `CLAUDE_CONFIG_DIR` resolves. The vendor page beside it says the same thing; what the artifact adds is that a wrong path here would now be visible to something rather than to nobody.

## Where the other harnesses keep theirs

| harness | path | shape |
|---|---|---|
| `antigravity` | `config/rules` | directory |
| **this one** | `CLAUDE.md` | file |
| `codex` | `AGENTS.md` | file |
| `cursor` | `rules` | directory |
| `grok` | `AGENTS.md` | file |
| `opencode` | `AGENTS.md` | file |
| `pi` | `AGENTS.md` | file |

**They are not interchangeable, and the difference is not only the
name.** One of the seven takes a *directory* of rules rather than a
single document, so a file moved between the two is not a rename.

**Some products read a neighbour's.** `references/surfaces.md` records
every such cross-read this estate has measured, on the declined rows:
a file written for one product can change what a second one sees, and
removing a setup can change what a third one sees. That is a property
of the products, not of this program, and it is the reason the declined
list is worth reading before writing here.

## Before you write one

- **This file is the floor, not the ceiling.** A repository's own
  instructions sit above it; write what is true everywhere and leave
  the rest to the project.
- **Read it back where the product reads it**, not where the install
  put it. Several of these products resolve a home through an override
  chain, and the two are not always the same directory.

