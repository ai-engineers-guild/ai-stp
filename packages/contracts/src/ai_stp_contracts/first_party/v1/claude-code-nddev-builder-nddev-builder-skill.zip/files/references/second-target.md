# The scoped target this harness owns

## `target_scope: project`, rooted at `project root`

**This scope's target is the workspace root** (the record names
its anchor `project root`), not this product's configuration home.
It is a different target, reached by a consumer naming the
scope on the request, and every path below is relative to the
workspace root -- a product-owned directory stays part of the
path.

| path | routes | decided by | exercised by |
|---|---|---|---|
| `CLAUDE.md` | instruction | <https://code.claude.com/docs/en/memory; re-read 2026-09-03 for Claude Code 2.1.259> | *nothing -- a page* |
### `CLAUDE.md`, as measured

Anthropic's current scope table names both ./CLAUDE.md and ./.claude/CLAUDE.md as team-shared project instructions. This first profile owns only the repository-root spelling: the immutable adaptation selects it, while claiming both would give one instruction kind two destinations without a selector.


Considered under this scope and not owned:

- **`.claude/CLAUDE.md`** — The product reads it, but the first explicit project adaptation selects repository-root CLAUDE.md. Owning both would make one component kind ambiguous until its immutable adaptation names the alternate member.
- **`CLAUDE.local.md`** — The vendor defines this as private local project preference and recommends gitignore. A public setup must not replace a person's local override.
- **`AGENTS.md`** — **New in 2.1.277, dated 2026-09-18 from the vendor's changelog**: in a project with no CLAUDE.md, Claude Code reads AGENTS.md instead (not yet on Bedrock, Vertex or Foundry). It is the instruction file four other harnesses in this estate own, so a repository written for them now reaches this product too -- a cross-read that did not exist when this surface was last measured, and the reason the repository-root CLAUDE.md this profile owns is also what suppresses it. Not owned: writing it would compete with four other products' writers for the same file, at a scope where a checkout's own file outranks any install.


**A complete setup may include these scoped components.** Each
provider request still reaches one root. The consumer coordinates
the roots with `ai-stp install transaction plan`, exact digest
approval, apply and recovery. A shipped configuration-home preset
cannot reach this root by nesting a path inside its home payload.
Declare the component's actual scope and bind the matching root
explicitly in the transaction.

**The root is shared, and that changes what removal means.** Several
products read it. Under this scope `remove`, the backup and a
restore act on the files this provider recorded writing rather than
on the directory whole, so a neighbour's files are never captured
into a slot here and never reverted out of one.

